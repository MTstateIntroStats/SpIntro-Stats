This is a resubmission of shinythemes 1.0 with updated license information.

All copyright holders for various included components are listed as "ctb" and "cph" in Authors@R. For some of the fonts, the copyright holders are organizations, not natural persons. No information is available regarding the persons who created the font, so in those cases, I have listed the organizations as "ctb" and "cph".
